package GreyModel.src.GM;

import java.text.DecimalFormat;

public class LinearTraj {
    public static int binarySearch(double[] arr,double key,int low,int high){

        if(key < arr[low] || key > arr[high] || low > high){
            return -1;
        }

        int middle = (low + high) / 2;			//初始中间位置
        if(arr[middle] > key){
            //比关键字大则关键字在左区域
            if(arr[middle-1]<key)
                return middle-1;
            return binarySearch(arr, key, low, middle - 1);
        }else if(arr[middle] < key){
            if(arr[middle+1]>key)
                return middle;
            //比关键字小则关键字在右区域
            return binarySearch(arr, key, middle + 1, high);
        }else {
            return middle;
        }

    }

    public static void main(String[] args) {

        DecimalFormat df = new DecimalFormat("0.0000");

      //  double[] x = {6,15,60,75,240,375,540,735,960,1215,1500,1815,2160,2535,2940,3840,6000,12000,24000,82800,86400};
        double[] x = {6,15,60,75,240,375,540,735,960,1215,1500,1815,2160,2535,2940,3840,6000};
        double[] x1= new double[x.length];
        for(int i=0;i<x1.length;i++) {
            x1[i]=Math.log10(x[i]);
            System.out.print(x1[i]+ " ");
        }
        System.out.println();
        double[] y = {0.469,0.451,0.431,0.427,0.384,0.381,0.378,0.375,0.367,0.361,0.36,0.359,0.359,0.358,0.357,0.354,0.351,0.347,0.342,0.333,0.333};
        double[] x_tar={1,1.5,2,2.5,3,3.5,4,4.5};
        for(int i=0;i<x_tar.length;i++) {
            int loc = binarySearch(x1, x_tar[i], 0, x.length - 1);
            if (loc == -1) {
                System.out.println("Out of Bound!");
            }
            if (loc == x.length - 1) {
                System.out.println(y[loc]);
            } else {
                double y_cap;
                y_cap = (y[loc + 1] - y[loc]) / (x1[loc + 1] - x1[loc]) * (x_tar[i] - x1[loc]) + y[loc];
                System.out.println(x_tar[i]+" "+df.format(y_cap));
            }
        }
    }

    public static double[] trajValue(double[] x, double[] y, double[] x_tar) {
        DecimalFormat df = new DecimalFormat("0.0000");
        double[] result=new double[x_tar.length];

        double[] x1= new double[x.length];
        for(int i=0;i<x1.length;i++) {
            x1[i]=Math.log10(x[i]);
//            System.out.print(x1[i]+ " ");
        }

        for(int i=0;i<x_tar.length;i++) {
            int loc = binarySearch(x1, x_tar[i], 0, x.length - 1);
            if (loc == -1) {
                System.out.println("Out of Bound!");
                break;
            }
            if (loc == x.length - 1) {
                System.out.println(y[loc]);
                result[i]=y[loc];
            } else {
                double y_cap;
                y_cap = (y[loc + 1] - y[loc]) / (x1[loc + 1] - x1[loc]) * (x_tar[i] - x1[loc]) + y[loc];
                System.out.println(x_tar[i]+" "+df.format(y_cap));
                result[i]=y_cap;
            }

        }
        return result;
    }
}
