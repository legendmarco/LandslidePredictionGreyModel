package GreyModel.src.GM;

/**
 * Created by Marco on 2023/12/26.
 */
public class DGM {
    private double[] X1;  //1-AGO
    private Matrix Y;
    private Matrix B;
    private Matrix Beta_cap;
    private double beta1,beta2;
    public DGM(double[] X0) {
        setX1(X0);
        setY(X1);
        setB(X1);
        setBeta_cap();
    }


    public void setX1(double[] X0) {
        X1=new double[X0.length];
        double x_tmp=0;
        for(int i=0;i<X1.length;i++) {
            x_tmp=x_tmp+X0[i];
            X1[i]=x_tmp;
        }
    }

    public double[] getX1() {
        return X1;
    }

    public Matrix getY() {
        return Y;
    }

    public void setY(double[] X1) {
        double[][] tmp= new double[X1.length-1][1];
        for(int i=0;i<X1.length-1;i++) {
            tmp[i][0]=X1[i+1];
        }
        Y=new Matrix(X1.length-1,1,tmp);
    }

    public Matrix getB() {
        return B;
    }

    public void setB(double[] X1) {
        double[][] tmp= new double[X1.length-1][2];
        for(int i=0;i<X1.length-1;i++) {
            tmp[i][0]=X1[i];
            tmp[i][1]=1;
        }
        B=new Matrix(X1.length-1,2,tmp);
    }

    public Matrix getBeta_cap() {
        return Beta_cap;
    }

    public void setBeta_cap() {
        Matrix BTB = B.transpose().multiply(B);
        Beta_cap = BTB.Mrinv().multiply(B.transpose()).multiply(Y);
        beta1=Beta_cap.Data[0][0];
        beta2=Beta_cap.Data[1][0];
    }

    public double getBeta1() {
        return beta1;
    }

    public double getBeta2() {
        return beta2;
    }
}
