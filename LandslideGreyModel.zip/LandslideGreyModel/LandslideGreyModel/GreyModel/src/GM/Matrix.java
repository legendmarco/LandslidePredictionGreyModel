package GreyModel.src.GM; /**
 * Created by Marco on 2023/12/26.
 */
import java.text.DecimalFormat;

class Matrix {

    private int row;//行

    private int col;//列

    //private double value;

    double [][]Data;



    public Matrix(int row, int col, double [][]Data) {

        this.row = row;

        this.col = col;

        //    this.value = value;

        this.Data = Data;

    }

    public void setMatrix(int row , int col, double value) {

        this.Data[row - 1][col - 1] = value;

    }

    public double getMatrix(int row, int col) {

        return Data[row - 1][col - 1] ;

    }

    public int width() {

        return row;

    }

    public int height() {

        return col;

    }

    public Matrix add(Matrix b) {

        if(this.width() != b.width() && this.height() != b.height()) {

            return null;

        }

        double add[][] = new double[this.row][this.col];

        for(int i = 0;i<row;i++) {

            for(int j = 0;j<col;j++) {

                add[i][j] = this.Data[i][j] + b.Data[i][j];

            }

        }

        Matrix another = new Matrix(this.row,this.col,add);

        System.out.println("after add:");

        return another;

    }

    public Matrix multiply(Matrix b) {

        if(this.col != b.row) {

            return null;

        }

        double mul[][] = new double[this.row][b.col];

        double temp = 0;

        for(int i = 0;i<this.row;i++) {

            for(int k = 0;k<b.col;k++) {

                for(int j = 0;j<this.col;j++)

                {

                    temp += this.Data[i][j] * b.Data[j][k];

                }

                mul[i][k] = temp;

                temp = 0;

            }

        }

        Matrix another = new Matrix(this.row, b.col, mul);

     //   System.out.println("after multiply:");

        return another;

    }

    public Matrix transpose() {

        double tran[][] = new double[this.col][this.row];

        for(int i = 0;i<this.row;i++) {

            for(int j = 0;j<this.col;j++) {

                tran[j][i] = this.Data[i][j];

            }

        }

        Matrix another = new Matrix(this.col,this.row,tran);

       // System.out.println("after transpose:");

        return another;

    }

    public Matrix Mrinv() {
        int n = col;
        if(col!=row) {
            return null;
        }
        double[][] a =new double[n][n];
        for (int i=0;i<n;i++) {
            for(int j=0;j<n;j++) {
                a[i][j] = Data[i][j];
            }
        }
        int i, j, row, col, k;
        double max, temp;
        int[] p = new int[n];
        double[][] b = new double[n][n];
        for (i = 0; i < n; i++) {
            p[i] = i;
            b[i][i] = 1;
        }

        for (k = 0; k < n; k++) {
            // 找主元
            max = 0;
            row = col = i;
            for (i = k; i < n; i++)
                for (j = k; j < n; j++) {
                    temp = Math.abs(b[i][j]);
                    if (max < temp) {
                        max = temp;
                        row = i;
                        col = j;
                    }
                }
            // 交换行列，将主元调整到 k 行 k 列上
            if (row != k) {
                for (j = 0; j < n; j++) {
                    temp = a[row][j];
                    a[row][j] = a[k][j];
                    a[k][j] = temp;
                    temp = b[row][j];
                    b[row][j] = b[k][j];
                    b[k][j] = temp;
                }
                i = p[row];
                p[row] = p[k];
                p[k] = i;
            }
            if (col != k) {
                for (i = 0; i < n; i++) {
                    temp = a[i][col];
                    a[i][col] = a[i][k];
                    a[i][k] = temp;
                }
            }
            // 处理
            for (j = k + 1; j < n; j++)
                a[k][j] /= a[k][k];
            for (j = 0; j < n; j++)
                b[k][j] /= a[k][k];
            a[k][k] = 1;

            for (j = k + 1; j < n; j++) {
                for (i = 0; i < k; i++)
                    a[i][j] -= a[i][k] * a[k][j];
                for (i = k + 1; i < n; i++)
                    a[i][j] -= a[i][k] * a[k][j];
            }
            for (j = 0; j < n; j++) {
                for (i = 0; i < k; i++)
                    b[i][j] -= a[i][k] * b[k][j];
                for (i = k + 1; i < n; i++)
                    b[i][j] -= a[i][k] * b[k][j];
            }
            for (i = 0; i < k; i++)
                a[i][k] = 0;
            a[k][k] = 1;
        }
        // 恢复行列次序；
        for (j = 0; j < n; j++)
            for (i = 0; i < n; i++)
                a[p[i]][j] = b[i][j];
        return new Matrix(n,n,a);
    }






    public String toString() {

        DecimalFormat df = new DecimalFormat("0.0000000");

        String result = "";

        //result += df.format(Data[0][0]);



        for(int i = 0;i<this.row;i++) {

            result += df.format(Data[i][0]);

            for(int j = 1;j<this.col;j++) {

                result += " " + df.format(Data[i][j]);

            }

            result +=  "\n";

        }

        return result;

    }



}
