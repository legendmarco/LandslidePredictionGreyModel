package GreyModel.src.GM;

import java.util.ArrayList;

/**
 * Original Differential Grey Model
 * Created by Marco on 2023/12/26.
 */
public class ODGM {
    private double[] X1;  //1-AGO
    private Matrix Y;
    private Matrix B;
    private Matrix a_cap;
    private double a,b;
    public ODGM(double[] X0) {
        setX1(X0);
        setY(X0);
        setB(X1);
        setA_cap();
    }

    public ODGM(ArrayList<Double> list) {
        int length = list.size();
        double[] X0 = new double[length];
        for(int i=0; i<length; i++) {
            X0[i]= list.get(i);
        }
        setX1(X0);
        setY(X0);
        setB(X1);
        setA_cap();

    }


    public void setX1(double[] X0) {
        X1=new double[X0.length];
        double x_tmp=0;
        for(int i=0;i<X1.length;i++) {
            x_tmp=x_tmp+X0[i];
            X1[i]=x_tmp;
        }
    }

    public double[] getX1() {
        return X1;
    }

    public Matrix getY() {
        return Y;
    }

    public void setY(double[] X0) {
        double[][] tmp= new double[X0.length-1][1];
        for(int i=0;i<X0.length-1;i++) {
            tmp[i][0]=X0[i+1];
        }
        Y=new Matrix(X0.length-1,1,tmp);
    }

    public Matrix getB() {
        return B;
    }

    public void setB(double[] X1) {
       double[][] tmp= new double[X1.length-1][2];
       for(int i=0;i<X1.length-1;i++) {
           tmp[i][0]=-X1[i+1];
           tmp[i][1]=1;
       }
       B=new Matrix(X1.length-1,2,tmp);
    }

    public Matrix getA_cap() {
        return a_cap;
    }

    public void setA_cap() {
        Matrix BTB = B.transpose().multiply(B);
        a_cap = BTB.Mrinv().multiply(B.transpose()).multiply(Y);
        a=a_cap.Data[0][0];
        b=a_cap.Data[1][0];
    }

    public double getParaA() {
        return a;
    }

    public double getParaB() {
        return b;
    }
}
