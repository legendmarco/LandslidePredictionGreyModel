package GreyModel.src.GM;

/**
 * Created by Marco on 2023/12/26.
 */
public class EGM {
    private double[] Z1;  //1-AGO
    private Matrix Y;
    private Matrix B;
    private Matrix a_cap;
    private double a,b;
    public EGM(double[] X0) {
        setZ1(X0);
        setY(X0);
        setB(Z1);
        setA_cap();
    }


    public void setZ1(double[] X0) {
        double[] X1=new double[X0.length];
        double x_tmp=0;
        for(int i=0;i<X1.length;i++) {
            x_tmp=x_tmp+X0[i];
            X1[i]=x_tmp;
        }
        Z1 = new double[X1.length-1];
        for(int i=0;i<Z1.length;i++) {
            Z1[i] = (X1[i]+X1[i+1])/2;
        }
    }

    public double[] getZ1() {
        return Z1;
    }

    public Matrix getY() {
        return Y;
    }

    public void setY(double[] X0) {
        double[][] tmp= new double[X0.length-1][1];
        for(int i=0;i<X0.length-1;i++) {
            tmp[i][0]=X0[i+1];
        }
        Y=new Matrix(X0.length-1,1,tmp);
    }

    public Matrix getB() {
        return B;
    }

    public void setB(double[] Z1) {
        double[][] tmp= new double[Z1.length][2];
        for(int i=0;i<Z1.length;i++) {
            tmp[i][0]=-Z1[i];
            tmp[i][1]=1;
        }
        B=new Matrix(Z1.length,2,tmp);
    }

    public Matrix getA_cap() {
        return a_cap;
    }

    public void setA_cap() {
        Matrix BTB = B.transpose().multiply(B);
        a_cap = BTB.Mrinv().multiply(B.transpose()).multiply(Y);
        a=a_cap.Data[0][0];
        b=a_cap.Data[1][0];
    }

    public double getParaA() {
        return a;
    }

    public double getParaB() {
        return b;
    }
}
