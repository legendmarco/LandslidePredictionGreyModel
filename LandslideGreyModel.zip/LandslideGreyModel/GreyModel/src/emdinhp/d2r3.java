package emdinhp;

public class d2r3 {
    public static void main(String []args)
    {
        double  x[]={6,15,60,75,240,375};
        double y[]={0.469,0.451,0.431,0.427,0.384,0.381};
        int n=6;
        double pi=3.14;
        int yy[]={240,241,242,243,244,245,369,370,371,372,373,374};
        double x1[]=new double[n+2];
        double y1[]=new double[n+2];
        x1[0]=y1[0]=0;
        x1[n+1]=y1[n+1]=0;
        for(int i=1;i<n+1;i++)
        {
            x1[i]=x[i-1];
            y1[i]=y[i-1];
        }
        chazhi ca=new chazhi(x1 ,y1, n+2);
        double s[]=ca.s(yy);
        for (int i=0;i<s.length;i++)
        {
            System.out.println(s[i]+"  ");
        }
    }
}
