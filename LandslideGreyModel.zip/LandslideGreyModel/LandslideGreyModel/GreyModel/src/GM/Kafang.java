package GreyModel.src.GM;

public class Kafang {
        public static void main(String[] args) {
            double[] x={5.2526,5.2675,5.2875,5.3124,5.3467};
            double[] y={5.2486,5.2568,5.2844,5.3110,5.3257};
            //5.2794,5.3037,5.3280,5.3525,5.3770
            //5.2908,5.3767,5.5129,5.7288,6.0709
            //5.7630,5.7582,5.9146,5.4860,5.4207
            if (x.length != y.length) {
                System.out.println("Wrong Inout!");
            }
            else {
                int length=x.length;
                double[] tmp = new double[length];
                double sum = 0;
                for (int i=0;i<length;i++) {
                    tmp[i] = x[i]-y[i];
                    sum=sum+tmp[i]*tmp[i];
                }
                double ka2 = sum/length;
//                double ka2 = Math.sqrt(sum)/length;
                System.out.println(ka2);
            }
        }
}
